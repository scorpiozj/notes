function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, value));
}

const renderCaches = new WeakMap();

function getRenderCache(context) {
  let cache = renderCaches.get(context);
  if (!cache) {
    cache = {
      holderCenterX: 0,
      holderBaseY: 0,
      holderWidth: 0,
      holderBedLevel: -1,
      holderPixelWidth: 0,
      holderPixelHeight: 0,
      bronze: null,
      bodyShade: null,
      ashBed: null,
      stickCenterX: 0,
      stickWidth: 0,
      stickPixelWidth: 0,
      stickPixelHeight: 0,
      stickGradient: null,
    };
    renderCaches.set(context, cache);
  }
  return cache;
}

function drawHolder(context, centerX, baseY, width, ashSystem) {
  const height = width * 0.34;
  const topY = baseY - height;
  const bellyY = topY + height * 0.48;
  const footTopY = topY + height * 0.7;
  const bedLevel = ashSystem.bedLevel;
  const bedRadius = width * (0.31 + bedLevel * 0.08);
  const bedHeight = height * (0.038 + bedLevel * 0.035);
  const bedY = topY - height * bedLevel * 0.012;
  const cache = getRenderCache(context);
  const pixelWidth = context.canvas?.width ?? 0;
  const pixelHeight = context.canvas?.height ?? 0;
  const holderChanged =
    cache.holderCenterX !== centerX ||
    cache.holderBaseY !== baseY ||
    cache.holderWidth !== width ||
    cache.holderBedLevel !== bedLevel ||
    cache.holderPixelWidth !== pixelWidth ||
    cache.holderPixelHeight !== pixelHeight;

  if (holderChanged) {
    cache.holderCenterX = centerX;
    cache.holderBaseY = baseY;
    cache.holderWidth = width;
    cache.holderBedLevel = bedLevel;
    cache.holderPixelWidth = pixelWidth;
    cache.holderPixelHeight = pixelHeight;
    cache.bronze = context.createLinearGradient(
      centerX - width * 0.48,
      0,
      centerX + width * 0.48,
      0,
    );
    cache.bronze.addColorStop(0, "#241f19");
    cache.bronze.addColorStop(0.17, "#5c5039");
    cache.bronze.addColorStop(0.42, "#887552");
    cache.bronze.addColorStop(0.62, "#514932");
    cache.bronze.addColorStop(0.86, "#766344");
    cache.bronze.addColorStop(1, "#201c17");

    cache.bodyShade = context.createLinearGradient(0, topY, 0, topY + height * 0.84);
    cache.bodyShade.addColorStop(0, "rgb(168 143 91 / 24%)");
    cache.bodyShade.addColorStop(0.25, "rgb(85 75 50 / 0%)");
    cache.bodyShade.addColorStop(1, "rgb(14 13 11 / 68%)");

    cache.ashBed = context.createRadialGradient(centerX, bedY, 0, centerX, bedY, bedRadius);
    cache.ashBed.addColorStop(0, "#a19d91");
    cache.ashBed.addColorStop(0.58, "#77746b");
    cache.ashBed.addColorStop(1, "#34342f");
  }

  context.beginPath();
  context.ellipse(centerX, baseY + height * 0.07, width * 0.39, height * 0.09, 0, 0, Math.PI * 2);
  context.fillStyle = "rgb(2 3 2 / 38%)";
  context.fill();

  context.lineWidth = Math.max(2, width * 0.022);
  context.strokeStyle = "#4c422f";
  for (const side of [-1, 1]) {
    context.beginPath();
    context.ellipse(
      centerX + side * width * 0.47,
      topY + height * 0.18,
      width * 0.13,
      height * 0.27,
      0,
      0,
      Math.PI * 2,
    );
    context.stroke();
  }

  for (const side of [-1, 1]) {
    context.beginPath();
    context.moveTo(centerX + side * width * 0.2, footTopY);
    context.bezierCurveTo(
      centerX + side * width * 0.2,
      baseY - height * 0.08,
      centerX + side * width * 0.3,
      baseY - height * 0.04,
      centerX + side * width * 0.27,
      baseY,
    );
    context.lineTo(centerX + side * width * 0.12, baseY);
    context.bezierCurveTo(
      centerX + side * width * 0.14,
      baseY - height * 0.12,
      centerX + side * width * 0.11,
      footTopY,
      centerX + side * width * 0.2,
      footTopY,
    );
    context.fillStyle = cache.bronze;
    context.fill();
  }

  context.beginPath();
  context.moveTo(centerX - width * 0.47, topY + height * 0.08);
  context.bezierCurveTo(
    centerX - width * 0.48,
    bellyY,
    centerX - width * 0.36,
    topY + height * 0.8,
    centerX,
    topY + height * 0.82,
  );
  context.bezierCurveTo(
    centerX + width * 0.36,
    topY + height * 0.8,
    centerX + width * 0.48,
    bellyY,
    centerX + width * 0.47,
    topY + height * 0.08,
  );
  context.closePath();
  context.fillStyle = cache.bronze;
  context.fill();
  context.fillStyle = cache.bodyShade;
  context.fill();

  context.strokeStyle = "rgb(27 55 45 / 46%)";
  context.lineWidth = Math.max(1, width * 0.008);
  context.beginPath();
  context.moveTo(centerX - width * 0.35, bellyY);
  context.quadraticCurveTo(centerX - width * 0.22, bellyY - height * 0.18, centerX - width * 0.09, bellyY);
  context.quadraticCurveTo(centerX, bellyY + height * 0.15, centerX + width * 0.09, bellyY);
  context.quadraticCurveTo(centerX + width * 0.22, bellyY - height * 0.18, centerX + width * 0.35, bellyY);
  context.stroke();

  context.fillStyle = "rgb(38 77 62 / 28%)";
  context.beginPath();
  context.ellipse(centerX - width * 0.24, bellyY + height * 0.14, width * 0.07, height * 0.09, -0.35, 0, Math.PI * 2);
  context.ellipse(centerX + width * 0.31, bellyY - height * 0.05, width * 0.045, height * 0.07, 0.45, 0, Math.PI * 2);
  context.fill();

  context.beginPath();
  context.ellipse(centerX, topY, width * 0.5, height * 0.13, 0, 0, Math.PI * 2);
  context.fillStyle = "#8f7a52";
  context.fill();

  context.beginPath();
  context.ellipse(centerX, topY, width * 0.435, height * 0.082, 0, 0, Math.PI * 2);
  context.fillStyle = "#171713";
  context.fill();

  context.beginPath();
  context.ellipse(centerX, bedY, bedRadius, bedHeight, 0, 0, Math.PI * 2);
  context.fillStyle = cache.ashBed;
  context.fill();

  context.fillStyle = "rgb(223 219 207 / 22%)";
  for (let row = -1; row <= 1; row += 1) {
    for (let column = -4; column <= 4; column += 1) {
      const normalizedX = column / 4.5;
      const normalizedY = row / 2.2;
      if (normalizedX * normalizedX + normalizedY * normalizedY > 1) {
        continue;
      }
      context.beginPath();
      context.arc(
        centerX + normalizedX * bedRadius * 0.82,
        bedY + normalizedY * bedHeight * 0.68,
        Math.max(0.35, width * 0.0022),
        0,
        Math.PI * 2,
      );
      context.fill();
    }
  }

  context.strokeStyle = "rgb(218 190 127 / 32%)";
  context.lineWidth = Math.max(0.8, width * 0.006);
  context.beginPath();
  context.ellipse(centerX, topY, width * 0.485, height * 0.12, 0, 0, Math.PI * 2);
  context.stroke();
}

function drawEmber(context, x, y, radius, color, intensity, scale, spark) {
  const scaledRadius = radius * scale;
  const glowRadius = scaledRadius * 4.4;
  const glow = context.createRadialGradient(x, y, scaledRadius * 0.15, x, y, glowRadius);
  glow.addColorStop(0, `rgb(235 91 35 / ${intensity * 0.42})`);
  glow.addColorStop(0.42, `rgb(218 62 24 / ${intensity * 0.2})`);
  glow.addColorStop(1, "rgb(218 62 24 / 0%)");
  context.beginPath();
  context.arc(x, y, glowRadius, 0, Math.PI * 2);
  context.fillStyle = glow;
  context.fill();

  const emberBody = context.createRadialGradient(
    x - scaledRadius * 0.16,
    y - scaledRadius * 0.12,
    scaledRadius * 0.08,
    x,
    y,
    scaledRadius * 1.45,
  );
  emberBody.addColorStop(0, `rgb(255 184 91 / ${0.82 + intensity * 0.18})`);
  emberBody.addColorStop(0.34, color);
  emberBody.addColorStop(0.76, "#9f2718");
  emberBody.addColorStop(1, "rgb(87 22 17 / 0%)");
  context.beginPath();
  context.ellipse(x, y, scaledRadius * 1.1, scaledRadius * 0.82, 0, 0, Math.PI * 2);
  context.fillStyle = emberBody;
  context.fill();

  const core = context.createRadialGradient(
    x - scaledRadius * 0.2,
    y - scaledRadius * 0.12,
    0,
    x,
    y,
    scaledRadius * 0.72,
  );
  core.addColorStop(0, `rgb(255 238 188 / ${intensity * 0.9})`);
  core.addColorStop(0.38, `rgb(255 134 55 / ${intensity * 0.72})`);
  core.addColorStop(1, "rgb(239 73 31 / 0%)");
  context.beginPath();
  context.arc(x, y, scaledRadius * 0.72, 0, Math.PI * 2);
  context.fillStyle = core;
  context.fill();

  if (spark.active) {
    const progress = spark.age / spark.lifetime;
    const sparkOpacity = Math.sin(progress * Math.PI) * 0.42;
    const sparkX = x + spark.offsetX + spark.driftSpeed * spark.age;
    const sparkY = y - scaledRadius - spark.riseSpeed * spark.age;
    context.beginPath();
    context.arc(sparkX, sparkY, Math.max(0.45, scaledRadius * 0.18), 0, Math.PI * 2);
    context.fillStyle = `rgb(255 177 82 / ${sparkOpacity})`;
    context.fill();
  }
}

function drawSmoke(context, smokeSystem) {
  context.save();
  context.lineCap = "butt";
  context.lineJoin = "round";

  for (const particle of smokeSystem.particles) {
    if (!particle.active || particle.opacity <= 0) {
      continue;
    }

    const predecessor = smokeSystem.particles[particle.predecessorIndex];
    const hasConnectedPredecessor =
      predecessor?.active && predecessor.strandId === particle.strandId;
    if (!hasConnectedPredecessor) {
      continue;
    }

    const movementX = particle.position.x - particle.previousPosition.x;
    const movementY = particle.position.y - particle.previousPosition.y;
    const predecessorMovementX = predecessor.position.x - predecessor.previousPosition.x;
    const predecessorMovementY = predecessor.position.y - predecessor.previousPosition.y;
    const controlScale = 4.5;
    const lifeProgress = Math.min(1, particle.age / particle.lifetime);
    const predecessorProgress = Math.min(1, predecessor.age / predecessor.lifetime);
    const expansion = 0.24 + Math.sqrt((lifeProgress + predecessorProgress) * 0.5) * 0.76;
    const strandWidth = ((particle.size + predecessor.size) * 0.5) * expansion;
    const strandOpacity = Math.min(particle.opacity, predecessor.opacity);

    context.beginPath();
    context.moveTo(predecessor.position.x, predecessor.position.y);
    context.bezierCurveTo(
      predecessor.position.x + predecessorMovementX * controlScale,
      predecessor.position.y + predecessorMovementY * controlScale,
      particle.position.x - movementX * controlScale,
      particle.position.y - movementY * controlScale,
      particle.position.x,
      particle.position.y,
    );
    context.strokeStyle = `rgb(184 191 186 / ${strandOpacity * 0.14})`;
    context.lineWidth = Math.max(0.8, strandWidth * 1.65);
    context.stroke();

    context.strokeStyle = `rgb(207 212 207 / ${strandOpacity * 0.42})`;
    context.lineWidth = Math.max(0.48, strandWidth * 0.78);
    context.stroke();

    context.strokeStyle = `rgb(232 232 225 / ${strandOpacity * 0.68})`;
    context.lineWidth = Math.max(0.28, strandWidth * 0.26);
    context.stroke();
  }

  context.restore();
}

function drawAttachedAsh(context, layout, incense, ashSystem) {
  const pixelLength = incense.ashLength * layout.unitScale;
  const growthProgress = Math.min(1, incense.ashLength / ashSystem.attached.breakThreshold);
  const bend =
    ashSystem.attached.bendDirection *
    pixelLength *
    ashSystem.config.maxAttachedBendRatio *
    growthProgress *
    growthProgress;
  const tipX = layout.centerX + bend;
  const tipY = layout.emberY - pixelLength;

  context.save();
  context.lineCap = "round";
  context.beginPath();
  context.moveTo(layout.centerX, layout.emberY);
  context.bezierCurveTo(
    layout.centerX,
    layout.emberY - pixelLength * 0.42,
    tipX - bend * 0.22,
    layout.emberY - pixelLength * 0.82,
    tipX,
    tipY,
  );
  context.strokeStyle = "rgb(190 188 180 / 96%)";
  context.lineWidth = layout.stickWidth * 0.84;
  context.stroke();

  context.strokeStyle = "rgb(240 237 226 / 38%)";
  context.lineWidth = Math.max(0.35, layout.stickWidth * 0.18);
  context.stroke();
  context.restore();
}

function drawFallingAsh(context, ashSystem) {
  context.save();
  context.lineCap = "butt";

  for (const fragment of ashSystem.falling) {
    if (!fragment.active || fragment.opacity <= 0) {
      continue;
    }

    context.save();
    context.translate(fragment.position.x, fragment.position.y);
    context.rotate(fragment.rotation);
    context.beginPath();
    context.moveTo(0, -fragment.size.length * 0.5);
    context.quadraticCurveTo(
      fragment.bend,
      0,
      0,
      fragment.size.length * 0.5,
    );
    context.strokeStyle = `rgb(189 187 178 / ${fragment.opacity * 0.82})`;
    context.lineWidth = fragment.size.width;
    context.stroke();

    context.strokeStyle = `rgb(235 231 219 / ${fragment.opacity * 0.38})`;
    context.lineWidth = Math.max(0.35, fragment.size.width * 0.24);
    context.stroke();
    context.restore();
  }

  context.restore();
}

export function calculateSceneLayout(viewport, incense, sceneConfig, layout = {}) {
  const { width, height } = viewport;
  const centerX = width / 2;
  const holderWidth = clamp(
    width * sceneConfig.holderWidthRatio,
    sceneConfig.minHolderWidth,
    sceneConfig.maxHolderWidth,
  );
  const holderBaseY = height * 0.91;
  const holderTopY = holderBaseY - holderWidth * 0.34;
  const fullIncenseHeight = clamp(
    height * sceneConfig.incenseHeightRatio,
    sceneConfig.minIncenseHeight,
    sceneConfig.maxIncenseHeight,
  );
  const unitScale = fullIncenseHeight / incense.initialLength;
  const emberY = holderTopY - incense.currentLength * unitScale;
  const ashTopY = emberY - incense.ashLength * unitScale;
  const stickWidth = clamp(width * 0.006, 3, 5.5);

  layout.centerX = centerX;
  layout.holderWidth = holderWidth;
  layout.holderBaseY = holderBaseY;
  layout.holderTopY = holderTopY;
  layout.emberY = emberY;
  layout.ashTopY = ashTopY;
  layout.stickWidth = stickWidth;
  layout.unitScale = unitScale;
  return layout;
}

export function renderScene(
  context,
  viewport,
  incense,
  smokeSystem,
  ashSystem,
  sceneConfig,
  incenseConfig,
  layout = calculateSceneLayout(viewport, incense, sceneConfig),
) {
  const { width, height } = viewport;
  const { centerX, holderWidth, holderBaseY, holderTopY, emberY, ashTopY, stickWidth } = layout;
  context.clearRect(0, 0, width, height);

  drawSmoke(context, smokeSystem);

  drawHolder(context, centerX, holderBaseY, holderWidth, ashSystem);
  drawFallingAsh(context, ashSystem);

  const cache = getRenderCache(context);
  const pixelWidth = context.canvas?.width ?? 0;
  const pixelHeight = context.canvas?.height ?? 0;
  const stickChanged =
    cache.stickCenterX !== centerX ||
    cache.stickWidth !== stickWidth ||
    cache.stickPixelWidth !== pixelWidth ||
    cache.stickPixelHeight !== pixelHeight;
  if (stickChanged) {
    cache.stickCenterX = centerX;
    cache.stickWidth = stickWidth;
    cache.stickPixelWidth = pixelWidth;
    cache.stickPixelHeight = pixelHeight;
    cache.stickGradient = context.createLinearGradient(
      centerX - stickWidth / 2,
      0,
      centerX + stickWidth / 2,
      0,
    );
    cache.stickGradient.addColorStop(0, "#4a2519");
    cache.stickGradient.addColorStop(0.48, "#a45a35");
    cache.stickGradient.addColorStop(1, "#351a13");
  }
  context.fillStyle = cache.stickGradient;
  context.fillRect(centerX - stickWidth / 2, emberY, stickWidth, holderTopY - emberY + 4);

  drawAttachedAsh(context, layout, incense, ashSystem);

  if (incense.isBurning) {
    drawEmber(
      context,
      centerX,
      emberY,
      stickWidth * 0.95,
      incenseConfig.emberColor,
      incense.emberIntensity,
      incense.emberScale,
      incense.spark,
    );
  }
}