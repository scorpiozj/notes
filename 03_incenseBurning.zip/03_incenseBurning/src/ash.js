function createFragment() {
  return {
    active: false,
    settled: false,
    position: { x: 0, y: 0 },
    previousPosition: { x: 0, y: 0 },
    velocity: { x: 0, y: 0 },
    rotation: 0,
    angularVelocity: 0,
    age: 0,
    lifetime: 0,
    size: { length: 0, width: 0 },
    opacity: 0,
    bend: 0,
  };
}

export class AshSystem {
  constructor(config) {
    this.config = config;
    this.attached = {
      breakThreshold: this.createBreakThreshold(),
      timeSinceBreak: 0,
      bendDirection: Math.random() < 0.5 ? -1 : 1,
    };
    this.falling = Array.from({ length: config.maxFragments }, createFragment);
    this.activeCount = 0;
    this.bedLevel = config.defaultBedLevel;
    this.width = 1;
    this.height = 1;
  }

  createBreakThreshold() {
    return this.config.minBreakLength + Math.random() * this.config.breakLengthRange;
  }

  reset() {
    this.attached.breakThreshold = this.createBreakThreshold();
    this.attached.timeSinceBreak = 0;
    this.attached.bendDirection = Math.random() < 0.5 ? -1 : 1;
    for (const fragment of this.falling) {
      fragment.active = false;
    }
    this.activeCount = 0;
    this.bedLevel = this.config.defaultBedLevel;
  }

  resize(width, height, layout) {
    if (this.width > 1 && this.height > 1) {
      const scaleX = width / this.width;
      const scaleY = height / this.height;
      const sizeScale = Math.sqrt(scaleX * scaleY);
      for (const fragment of this.falling) {
        if (!fragment.active) {
          continue;
        }
        fragment.position.x *= scaleX;
        fragment.position.y *= scaleY;
        fragment.previousPosition.x *= scaleX;
        fragment.previousPosition.y *= scaleY;
        fragment.velocity.x *= scaleX;
        fragment.velocity.y *= scaleY;
        fragment.size.length *= sizeScale;
        fragment.size.width *= sizeScale;
        if (fragment.settled && layout) {
          const basinHalfWidth = layout.holderWidth * 0.34;
          fragment.position.x = Math.min(
            layout.centerX + basinHalfWidth,
            Math.max(layout.centerX - basinHalfWidth, fragment.position.x),
          );
          fragment.position.y = layout.holderTopY - fragment.size.width * 0.4;
          fragment.previousPosition.x = fragment.position.x;
          fragment.previousPosition.y = fragment.position.y;
        }
      }
    }
    this.width = width;
    this.height = height;
  }

  update(deltaTime, incense, layout, motionScale = 1) {
    this.attached.timeSinceBreak += deltaTime;
    this.updateFalling(deltaTime, layout, motionScale);

    if (
      incense.ashLength >= this.attached.breakThreshold &&
      this.attached.timeSinceBreak >= this.config.minBreakInterval
    ) {
      this.breakAttachedAsh(incense, layout, motionScale);
    }
  }

  breakAttachedAsh(incense, layout, motionScale) {
    const retainedLength = Math.min(
      incense.ashLength * 0.28,
      this.config.retainedLengthMin + Math.random() * this.config.retainedLengthRange,
    );
    const detachedLength = incense.ashLength - retainedLength;
    if (detachedLength <= 0) {
      return;
    }

    const fragment = this.acquireFragment();
    if (fragment) {
      const detachedPixelLength = detachedLength * layout.unitScale;
      fragment.active = true;
      fragment.settled = false;
      fragment.position.x = layout.centerX + (Math.random() - 0.5) * layout.stickWidth;
      fragment.position.y = layout.emberY - retainedLength * layout.unitScale - detachedPixelLength * 0.5;
      fragment.previousPosition.x = fragment.position.x;
      fragment.previousPosition.y = fragment.position.y;
      const bendDirection = this.attached.bendDirection;
      fragment.velocity.x = bendDirection * (4 + Math.random() * 3) * motionScale;
      fragment.velocity.y = 1.5 + Math.random() * 2.5;
      fragment.rotation = bendDirection * (0.035 + Math.random() * 0.035);
      fragment.angularVelocity = bendDirection * (0.35 + Math.random() * 0.45);
      fragment.age = 0;
      fragment.lifetime = this.config.fragmentLifetime;
      fragment.size.length = detachedPixelLength;
      fragment.size.width = layout.stickWidth * (0.72 + Math.random() * 0.18);
      fragment.opacity = 0.9;
      fragment.bend = bendDirection * detachedPixelLength * this.config.maxAttachedBendRatio;
      this.activeCount += 1;
    }

    incense.ashLength = retainedLength;
    this.attached.breakThreshold = this.createBreakThreshold();
    this.attached.timeSinceBreak = 0;
    this.attached.bendDirection = Math.random() < 0.5 ? -1 : 1;
  }

  acquireFragment() {
    for (const fragment of this.falling) {
      if (!fragment.active) {
        return fragment;
      }
    }

    let oldest = this.falling[0];
    for (const fragment of this.falling) {
      if (fragment.age > oldest.age) {
        oldest = fragment;
      }
    }
    oldest.active = false;
    this.activeCount -= 1;
    return oldest;
  }

  updateFalling(deltaTime, layout, motionScale) {
    const drag = Math.exp(-this.config.drag * deltaTime);
    const basinLeft = layout.centerX - layout.holderWidth * 0.38;
    const basinRight = layout.centerX + layout.holderWidth * 0.38;

    for (const fragment of this.falling) {
      if (!fragment.active) {
        continue;
      }

      fragment.age += deltaTime;
      if (fragment.settled) {
        const fadeAge = Math.max(0, fragment.age - this.config.settledHoldTime);
        const fadeProgress = Math.min(1, fadeAge / this.config.settledFadeTime);
        fragment.opacity = 1 - fadeProgress * fadeProgress;
        if (fadeProgress >= 1) {
          this.bedLevel = Math.min(
            this.config.maxBedLevel,
            this.bedLevel + this.config.bedDepositPerFragment,
          );
          this.recycle(fragment);
        }
        continue;
      }

      fragment.previousPosition.x = fragment.position.x;
      fragment.previousPosition.y = fragment.position.y;
      fragment.velocity.x *= drag;
      fragment.velocity.y = Math.min(
        this.config.maxFallSpeed,
        fragment.velocity.y * drag + this.config.gravity * deltaTime,
      );
      fragment.velocity.x +=
        Math.sin(fragment.age * 1.4 + fragment.rotation) *
        this.config.airDisturbance *
        motionScale *
        deltaTime;
      fragment.position.x += fragment.velocity.x * deltaTime;
      fragment.position.y += fragment.velocity.y * deltaTime;
      fragment.rotation += fragment.angularVelocity * motionScale * deltaTime;

      const previousLeadingEdge = fragment.previousPosition.y + fragment.size.length * 0.5;
      const leadingEdge = fragment.position.y + fragment.size.length * 0.5;
      const crossedBasin =
        previousLeadingEdge < layout.holderTopY && leadingEdge >= layout.holderTopY;
      const insideBasin = fragment.position.x >= basinLeft && fragment.position.x <= basinRight;
      if (crossedBasin && insideBasin) {
        fragment.position.y = layout.holderTopY - fragment.size.width * 0.4;
        fragment.velocity.x = 0;
        fragment.velocity.y = 0;
        fragment.angularVelocity = 0;
        fragment.rotation = Math.PI * 0.5 + fragment.rotation * 0.12;
        fragment.settled = true;
        fragment.age = 0;
        fragment.lifetime = this.config.settledHoldTime + this.config.settledFadeTime;
        continue;
      }

      if (
        fragment.age >= fragment.lifetime ||
        fragment.position.y - fragment.size.length > this.height ||
        fragment.position.x < -fragment.size.length ||
        fragment.position.x > this.width + fragment.size.length
      ) {
        this.recycle(fragment);
      }
    }
  }

  recycle(fragment) {
    fragment.active = false;
    this.activeCount -= 1;
  }
}