export const VIEWPORT_CONFIG = Object.freeze({
  maxDevicePixelRatio: 2,
  maxDeltaTime: 0.05,
});

export const CONTROL_CONFIG = Object.freeze({
  defaultSmokeIntensity: 50,
});

export const INCENSE_CONFIG = Object.freeze({
  initialLength: 100,
  initialAshLength: 3,
  burnRate: 0.32,
  emberColor: "#ef5b2a",
  emberIntensityMin: 0.72,
  emberIntensityRange: 0.26,
  emberScaleMin: 0.9,
  emberScaleRange: 0.2,
  emberSmoothing: 2.4,
  sparkIntervalMin: 4,
  sparkIntervalRange: 5,
  sparkLifetimeMin: 0.32,
  sparkLifetimeRange: 0.24,
  reducedMotionFlickerScale: 0.35,
});

export const SCENE_CONFIG = Object.freeze({
  incenseHeightRatio: 0.5,
  minIncenseHeight: 150,
  maxIncenseHeight: 390,
  holderWidthRatio: 0.28,
  minHolderWidth: 116,
  maxHolderWidth: 220,
});

export const SMOKE_CONFIG = Object.freeze({
  desktopMaxParticles: 120,
  mobileMaxParticles: 64,
  reducedMotionMaxParticles: 24,
  desktopEmissionRate: 18,
  mobileEmissionRate: 10,
  reducedMotionEmissionRate: 3,
  maxEmissionsPerFrame: 2,
  maxOpacity: 0.22,
  mobileBreakpoint: 600,
  reducedMotionDriftScale: 0.24,
});

export const ASH_CONFIG = Object.freeze({
  maxFragments: 10,
  minBreakLength: 7.5,
  breakLengthRange: 5.5,
  minBreakInterval: 7,
  maxAttachedBendRatio: 0.065,
  retainedLengthMin: 0.7,
  retainedLengthRange: 1.2,
  gravity: 88,
  drag: 0.45,
  airDisturbance: 1.4,
  maxFallSpeed: 92,
  fragmentLifetime: 7,
  settledHoldTime: 1.2,
  settledFadeTime: 2.4,
  defaultBedLevel: 0.46,
  maxBedLevel: 0.78,
  bedDepositPerFragment: 0.025,
  reducedMotionRotationScale: 0.28,
});