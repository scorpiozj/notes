export function createIncenseState(config) {
  return {
    initialLength: config.initialLength,
    currentLength: config.initialLength,
    burnProgress: 0,
    burnRate: config.burnRate,
    emberIntensity: 0.82,
    ashLength: config.initialAshLength,
    isBurning: true,
    elapsedTime: 0,
    flickerTarget: 0.82,
    flickerClock: 0,
    emberScale: 1,
    emberScaleTarget: 1,
    spark: {
      active: false,
      age: 0,
      lifetime: 0,
      delay: config.sparkIntervalMin + Math.random() * config.sparkIntervalRange,
      offsetX: 0,
      riseSpeed: 0,
      driftSpeed: 0,
    },
  };
}

function updateSpark(state, deltaTime, config, motionScale) {
  const spark = state.spark;

  if (spark.active) {
    spark.age += deltaTime;
    if (spark.age >= spark.lifetime) {
      spark.active = false;
      spark.delay = config.sparkIntervalMin + Math.random() * config.sparkIntervalRange;
    }
    return;
  }

  spark.delay -= deltaTime;
  if (spark.delay <= 0 && motionScale > 0.5) {
    spark.active = true;
    spark.age = 0;
    spark.lifetime = config.sparkLifetimeMin + Math.random() * config.sparkLifetimeRange;
    spark.offsetX = (Math.random() - 0.5) * 2;
    spark.riseSpeed = 7 + Math.random() * 5;
    spark.driftSpeed = (Math.random() - 0.5) * 4;
  }
}

export function updateIncense(state, deltaTime, config, motionScale = 1) {
  if (!state.isBurning || deltaTime <= 0) {
    return;
  }

  state.elapsedTime += deltaTime;
  state.currentLength = Math.max(0, state.currentLength - state.burnRate * deltaTime);
  state.burnProgress = 1 - state.currentLength / state.initialLength;
  state.ashLength += state.burnRate * deltaTime;

  state.flickerClock -= deltaTime;
  if (state.flickerClock <= 0) {
    state.flickerClock = 0.7 + Math.random() * 1.1;
    state.flickerTarget =
      config.emberIntensityMin + Math.random() * config.emberIntensityRange * motionScale;
    state.emberScaleTarget =
      config.emberScaleMin + Math.random() * config.emberScaleRange * motionScale;
  }

  const smoothing = 1 - Math.exp(-deltaTime * config.emberSmoothing);
  state.emberIntensity += (state.flickerTarget - state.emberIntensity) * smoothing;
  state.emberScale += (state.emberScaleTarget - state.emberScale) * smoothing;
  updateSpark(state, deltaTime, config, motionScale);

  if (state.currentLength === 0) {
    state.isBurning = false;
    state.emberIntensity = 0;
    state.spark.active = false;
  }
}

export function resetIncense(state, config) {
  Object.assign(state, createIncenseState(config));
}