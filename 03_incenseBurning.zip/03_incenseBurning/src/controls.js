const FINISHED_STATE = Object.freeze({
  disabled: true,
  text: "已燃尽",
  label: "线香已燃尽",
  pressed: true,
});

const RUNNING_STATE = Object.freeze({
  disabled: false,
  text: "暂停",
  label: "暂停线香燃烧",
  pressed: false,
});

const PAUSED_STATE = Object.freeze({
  disabled: false,
  text: "开始",
  label: "继续线香燃烧",
  pressed: true,
});

export function getToggleControlState(currentLength, running) {
  if (currentLength <= 0) {
    return FINISHED_STATE;
  }

  return running ? RUNNING_STATE : PAUSED_STATE;
}