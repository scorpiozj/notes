import {
  ASH_CONFIG,
  CONTROL_CONFIG,
  INCENSE_CONFIG,
  SCENE_CONFIG,
  SMOKE_CONFIG,
  VIEWPORT_CONFIG,
} from "./config.js";
import { AshSystem } from "./ash.js";
import { getToggleControlState } from "./controls.js";
import { createIncenseState, resetIncense, updateIncense } from "./incense.js";
import { calculateSceneLayout, renderScene } from "./renderer.js";
import { SmokeSystem } from "./smoke.js";
import { createViewport } from "./viewport.js";

const canvas = document.querySelector("#incense-canvas");
const toggleButton = document.querySelector("#toggle-burning");
const resetButton = document.querySelector("#reset-incense");
const smokeIntensityInput = document.querySelector("#smoke-intensity");

if (!(canvas instanceof HTMLCanvasElement)) {
  throw new Error("The incense canvas element is missing.");
}

const context = canvas.getContext("2d");

if (!context) {
  throw new Error("Canvas 2D is not supported by this browser.");
}

if (!(toggleButton instanceof HTMLButtonElement) || !(resetButton instanceof HTMLButtonElement)) {
  throw new Error("The incense controls are missing.");
}

if (!(smokeIntensityInput instanceof HTMLInputElement)) {
  throw new Error("The smoke intensity control is missing.");
}

const incense = createIncenseState(INCENSE_CONFIG);
const smokeSystem = new SmokeSystem(SMOKE_CONFIG);
const ashSystem = new AshSystem(ASH_CONFIG);
const { viewport, resize } = createViewport(
  canvas,
  context,
  VIEWPORT_CONFIG.maxDevicePixelRatio,
);
const motionPreference =
  typeof window.matchMedia === "function"
    ? window.matchMedia("(prefers-reduced-motion: reduce)")
    : { matches: false };
smokeIntensityInput.value = String(CONTROL_CONFIG.defaultSmokeIntensity);
const lifecycle = {
  userPaused: false,
  pageHidden: document.hidden,
};
const sceneLayout = {};
const smokeEmissionPoint = { x: 0, y: 0 };
const smokeUpdateOptions = {
  intensity: 0,
  mobile: false,
  reducedMotion: false,
  motionScale: 1,
};
const renderedControlState = {
  disabled: undefined,
  text: "",
  pressed: undefined,
  label: "",
  smokeValue: "",
};
let resizeFrameId = 0;
let animationFrameId = 0;
let previousTimestamp;

function canSimulate() {
  return !lifecycle.userPaused && !lifecycle.pageHidden && incense.currentLength > 0;
}

function draw() {
  renderScene(
    context,
    viewport,
    incense,
    smokeSystem,
    ashSystem,
    SCENE_CONFIG,
    INCENSE_CONFIG,
    sceneLayout,
  );
}

function scheduleResize() {
  if (resizeFrameId !== 0) {
    return;
  }

  resizeFrameId = window.requestAnimationFrame(() => {
    resizeFrameId = 0;
    if (!resize()) {
      return;
    }
    smokeSystem.resize(viewport.width, viewport.height);
    ashSystem.resize(
      viewport.width,
      viewport.height,
      calculateSceneLayout(viewport, incense, SCENE_CONFIG, sceneLayout),
    );
    draw();
  });
}

function updateControlState() {
  const controlState = getToggleControlState(incense.currentLength, canSimulate());
  const smokeValue = smokeIntensityInput.value;

  if (renderedControlState.disabled !== controlState.disabled) {
    renderedControlState.disabled = controlState.disabled;
    toggleButton.disabled = controlState.disabled;
  }
  if (renderedControlState.text !== controlState.text) {
    renderedControlState.text = controlState.text;
    toggleButton.textContent = controlState.text;
  }
  if (renderedControlState.pressed !== controlState.pressed) {
    renderedControlState.pressed = controlState.pressed;
    toggleButton.setAttribute("aria-pressed", String(controlState.pressed));
  }
  if (renderedControlState.label !== controlState.label) {
    renderedControlState.label = controlState.label;
    toggleButton.setAttribute("aria-label", controlState.label);
  }
  if (renderedControlState.smokeValue !== smokeValue) {
    renderedControlState.smokeValue = smokeValue;
    smokeIntensityInput.setAttribute("aria-valuetext", `${smokeValue}%`);
  }
}

function stopAnimationLoop() {
  if (animationFrameId !== 0) {
    window.cancelAnimationFrame(animationFrameId);
    animationFrameId = 0;
  }
  previousTimestamp = undefined;
}

function startAnimationLoop() {
  if (animationFrameId === 0 && canSimulate()) {
    previousTimestamp = undefined;
    incense.isBurning = true;
    animationFrameId = window.requestAnimationFrame(animate);
  }
}

function syncLifecycle() {
  updateControlState();

  if (canSimulate()) {
    startAnimationLoop();
  } else {
    stopAnimationLoop();
    draw();
  }
}

function animate(timestamp) {
  animationFrameId = 0;
  if (!canSimulate()) {
    syncLifecycle();
    return;
  }

  if (previousTimestamp === undefined) {
    previousTimestamp = timestamp;
  }

  const deltaTime = Math.min(
    (timestamp - previousTimestamp) / 1000,
    VIEWPORT_CONFIG.maxDeltaTime,
  );
  previousTimestamp = timestamp;

  updateIncense(
    incense,
    deltaTime,
    INCENSE_CONFIG,
    motionPreference.matches ? INCENSE_CONFIG.reducedMotionFlickerScale : 1,
  );
  if (incense.isBurning) {
    const layout = calculateSceneLayout(viewport, incense, SCENE_CONFIG, sceneLayout);
    const reducedMotion = motionPreference.matches;
    smokeEmissionPoint.x = layout.centerX;
    smokeEmissionPoint.y = layout.emberY;
    smokeUpdateOptions.intensity = Number(smokeIntensityInput.value) / 100;
    smokeUpdateOptions.mobile = viewport.width <= SMOKE_CONFIG.mobileBreakpoint;
    smokeUpdateOptions.reducedMotion = reducedMotion;
    smokeUpdateOptions.motionScale = reducedMotion ? SMOKE_CONFIG.reducedMotionDriftScale : 1;
    smokeSystem.update(
      deltaTime,
      smokeEmissionPoint,
      smokeUpdateOptions,
    );
    ashSystem.update(
      deltaTime,
      incense,
      layout,
      reducedMotion ? ASH_CONFIG.reducedMotionRotationScale : 1,
    );
  }
  updateControlState();
  draw();
  if (canSimulate()) {
    animationFrameId = window.requestAnimationFrame(animate);
  } else {
    incense.isBurning = false;
    previousTimestamp = undefined;
    updateControlState();
  }
}

toggleButton.addEventListener("click", () => {
  lifecycle.userPaused = !lifecycle.userPaused;
  syncLifecycle();
});

resetButton.addEventListener("click", () => {
  stopAnimationLoop();
  resetIncense(incense, INCENSE_CONFIG);
  smokeSystem.reset();
  ashSystem.reset();
  smokeIntensityInput.value = String(CONTROL_CONFIG.defaultSmokeIntensity);
  lifecycle.userPaused = false;
  lifecycle.pageHidden = document.hidden;
  draw();
  syncLifecycle();
});

smokeIntensityInput.addEventListener("input", updateControlState);

if (typeof window.ResizeObserver === "function") {
  const resizeObserver = new ResizeObserver(scheduleResize);
  resizeObserver.observe(canvas);
}

window.addEventListener("resize", scheduleResize, { passive: true });
window.addEventListener("orientationchange", scheduleResize, { passive: true });

document.addEventListener("visibilitychange", () => {
  lifecycle.pageHidden = document.hidden;
  syncLifecycle();
});

resize();
smokeSystem.resize(viewport.width, viewport.height);
ashSystem.resize(
  viewport.width,
  viewport.height,
  calculateSceneLayout(viewport, incense, SCENE_CONFIG, sceneLayout),
);
draw();
syncLifecycle();