export function createViewport(canvas, context, maxDevicePixelRatio) {
  const viewport = {
    width: 1,
    height: 1,
    devicePixelRatio: 1,
  };

  function resize() {
    const bounds = canvas.getBoundingClientRect();
    const width = Math.max(1, bounds.width);
    const height = Math.max(1, bounds.height);
    const devicePixelRatio = Math.min(
      window.devicePixelRatio || 1,
      maxDevicePixelRatio,
    );
    const pixelWidth = Math.round(width * devicePixelRatio);
    const pixelHeight = Math.round(height * devicePixelRatio);
    const viewportChanged =
      width !== viewport.width ||
      height !== viewport.height ||
      devicePixelRatio !== viewport.devicePixelRatio;
    const backingStoreChanged =
      canvas.width !== pixelWidth || canvas.height !== pixelHeight;

    viewport.width = width;
    viewport.height = height;
    viewport.devicePixelRatio = devicePixelRatio;

    if (backingStoreChanged) {
      canvas.width = pixelWidth;
      canvas.height = pixelHeight;
    }

    if (backingStoreChanged || viewportChanged) {
      context.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    }

    return viewportChanged || backingStoreChanged;
  }

  return { viewport, resize };
}