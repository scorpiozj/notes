function createParticle() {
  return {
    active: false,
    position: { x: 0, y: 0 },
    previousPosition: { x: 0, y: 0 },
    velocity: { x: 0, y: 0 },
    age: 0,
    lifetime: 0,
    size: 0,
    startSize: 0,
    endSize: 0,
    opacity: 0,
    driftPhase: 0,
    driftFrequency: 0,
    driftAmplitude: 0,
    strandId: 0,
    predecessorIndex: -1,
  };
}

function smoothstep(edgeStart, edgeEnd, value) {
  const progress = Math.min(1, Math.max(0, (value - edgeStart) / (edgeEnd - edgeStart)));
  return progress * progress * (3 - 2 * progress);
}

export class SmokeSystem {
  constructor(config) {
    this.config = config;
    this.particles = Array.from({ length: config.desktopMaxParticles }, createParticle);
    this.activeCount = 0;
    this.emissionAccumulator = 0;
    this.elapsedTime = 0;
    this.strandId = 0;
    this.strandClock = 0;
    this.strandPhase = 0;
    this.strandFrequency = 0;
    this.strandAmplitude = 0;
    this.lastStrandParticleIndex = -1;
    this.width = 1;
    this.height = 1;
  }

  reset() {
    for (const particle of this.particles) {
      particle.active = false;
    }
    this.activeCount = 0;
    this.emissionAccumulator = 0;
    this.elapsedTime = 0;
    this.strandClock = 0;
    this.lastStrandParticleIndex = -1;
  }

  resize(width, height) {
    if (this.width > 1 && this.height > 1) {
      const scaleX = width / this.width;
      const scaleY = height / this.height;
      for (const particle of this.particles) {
        if (!particle.active) {
          continue;
        }
        particle.position.x *= scaleX;
        particle.position.y *= scaleY;
        particle.previousPosition.x *= scaleX;
        particle.previousPosition.y *= scaleY;
        particle.velocity.x *= scaleX;
        particle.velocity.y *= scaleY;
      }
    }
    this.width = width;
    this.height = height;
  }

  update(deltaTime, emissionPoint, options) {
    this.elapsedTime += deltaTime;
    this.updateStrand(deltaTime, options.motionScale);

    const maxParticles = options.reducedMotion
      ? this.config.reducedMotionMaxParticles
      : options.mobile
        ? this.config.mobileMaxParticles
        : this.config.desktopMaxParticles;
    const emissionRate = options.reducedMotion
      ? this.config.reducedMotionEmissionRate
      : options.mobile
        ? this.config.mobileEmissionRate
        : this.config.desktopEmissionRate;

    this.enforceParticleLimit(maxParticles);

    this.emissionAccumulator += emissionRate * options.intensity * deltaTime;
    let emittedThisFrame = 0;
    while (
      this.emissionAccumulator >= 1 &&
      emittedThisFrame < this.config.maxEmissionsPerFrame &&
      this.activeCount < maxParticles
    ) {
      if (!this.activateParticle(emissionPoint, options.motionScale)) {
        break;
      }
      this.emissionAccumulator -= 1;
      emittedThisFrame += 1;
    }
    this.emissionAccumulator = Math.min(this.emissionAccumulator, 1);

    for (const particle of this.particles) {
      if (!particle.active) {
        continue;
      }
      this.updateParticle(particle, deltaTime, options.motionScale);
    }
  }

  enforceParticleLimit(maxParticles) {
    if (this.activeCount <= maxParticles) {
      return;
    }

    for (let index = this.particles.length - 1; index >= 0; index -= 1) {
      const particle = this.particles[index];
      if (particle.active) {
        particle.active = false;
        this.activeCount -= 1;
      }
      if (this.activeCount <= maxParticles) {
        break;
      }
    }
  }

  updateStrand(deltaTime, motionScale) {
    this.strandClock -= deltaTime;
    if (this.strandClock > 0) {
      return;
    }

    this.strandId += 1;
    this.lastStrandParticleIndex = -1;
    this.strandClock = 0.65 + Math.random() * 0.9;
    this.strandPhase = Math.random() * Math.PI * 2;
    this.strandFrequency = 0.55 + Math.random() * 0.45;
    this.strandAmplitude = (5 + Math.random() * 7) * motionScale;
  }

  activateParticle(emissionPoint, motionScale) {
    let particle;
    let particleIndex = -1;
    for (let index = 0; index < this.particles.length; index += 1) {
      if (!this.particles[index].active) {
        particle = this.particles[index];
        particleIndex = index;
        break;
      }
    }
    if (!particle) {
      return false;
    }

    const jitter = (Math.random() - 0.5) * 1.2;
    particle.active = true;
    particle.position.x = emissionPoint.x + jitter;
    particle.position.y = emissionPoint.y - 1;
    particle.previousPosition.x = particle.position.x;
    particle.previousPosition.y = particle.position.y + 0.5;
    particle.velocity.x = (Math.random() - 0.5) * 1.4 * motionScale;
    particle.velocity.y = -(22 + Math.random() * 10);
    particle.age = 0;
    particle.lifetime = 4.8 + Math.random() * 1.8;
    particle.startSize = 0.75 + Math.random() * 0.45;
    particle.endSize = 6.5 + Math.random() * 4;
    particle.size = particle.startSize;
    particle.opacity = 0;
    particle.driftPhase = this.strandPhase + (Math.random() - 0.5) * 0.28;
    particle.driftFrequency = this.strandFrequency * (0.92 + Math.random() * 0.16);
    particle.driftAmplitude = this.strandAmplitude * (0.86 + Math.random() * 0.28);
    particle.strandId = this.strandId;
    particle.predecessorIndex = this.lastStrandParticleIndex;
    this.lastStrandParticleIndex = particleIndex;
    this.activeCount += 1;
    return true;
  }

  updateParticle(particle, deltaTime, motionScale) {
    particle.age += deltaTime;
    const lifeProgress = particle.age / particle.lifetime;

    if (
      lifeProgress >= 1 ||
      particle.position.y < -particle.size * 3 ||
      particle.position.x < -particle.size * 3 ||
      particle.position.x > this.width + particle.size * 3
    ) {
      particle.active = false;
      this.activeCount -= 1;
      return;
    }

    particle.previousPosition.x = particle.position.x;
    particle.previousPosition.y = particle.position.y;

    const riseProgress = smoothstep(0, 1, lifeProgress);
    const primaryDrift = Math.sin(
      this.elapsedTime * particle.driftFrequency + particle.driftPhase,
    );
    const curl = Math.sin(
      this.elapsedTime * particle.driftFrequency * 1.73 + particle.driftPhase * 0.61,
    );
    const driftVelocity =
      (primaryDrift * 0.72 + curl * 0.28) *
      particle.driftAmplitude *
      (0.3 + riseProgress * 0.7) *
      motionScale;

    particle.position.x += (particle.velocity.x + driftVelocity) * deltaTime;
    particle.position.y += particle.velocity.y * deltaTime;
    particle.velocity.y += 1.8 * deltaTime;
    particle.size = particle.startSize + (particle.endSize - particle.startSize) * riseProgress;

    const fadeIn = smoothstep(0, 0.12, lifeProgress);
    const fadeOut = 1 - smoothstep(0.5, 1, lifeProgress);
    particle.opacity = fadeIn * fadeOut * this.config.maxOpacity;
  }
}