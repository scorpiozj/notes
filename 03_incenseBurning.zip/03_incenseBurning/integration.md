# 线香动画集成指南

## 结论

本项目可以移植到其他 Web 项目。核心模拟使用原生 JavaScript ES Modules 和 Canvas 2D，不依赖框架、构建工具、第三方运行时或外部资源。

当前实现适合以下集成方式：

1. **独立页面或 iframe**：推荐，隔离最完整，几乎无需修改现有代码。
2. **传统多页应用中的单个页面**：可以直接嵌入，但必须处理全局 CSS 影响。
3. **React、Vue、Angular 或客户端路由 SPA**：核心模块可以复用，但当前 `main.js` 是自动启动的页面级入口。若组件会反复挂载和卸载，应先封装 `mount()` / `destroy()` 生命周期，不能在每次挂载时重复导入入口。

## 运行要求

宿主环境需要支持：

- JavaScript ES Modules；
- Canvas 2D；
- `requestAnimationFrame` / `cancelAnimationFrame`；
- Page Visibility API；
- CSS `env(safe-area-inset-*)`（不支持时会自然退化为普通 padding）。

`ResizeObserver` 和 `matchMedia` 是可选能力。缺少 `ResizeObserver` 时使用窗口 resize/orientation 事件；缺少 `matchMedia` 时使用普通动态模式。

页面必须通过 HTTP(S) 提供，不能依赖双击 `index.html` 后的 `file://` 路径。现代开发服务器、静态服务器和主流打包工具均可。

## 文件依赖

复制以下文件，并保持 `src/` 内的相对路径不变：

```text
incense-burning/
  styles.css
  src/
    ash.js
    config.js
    controls.js
    incense.js
    main.js
    renderer.js
    smoke.js
    viewport.js
```

模块关系如下：

```mermaid
flowchart TD
  main[main.js] --> config[config.js]
  main --> controls[controls.js]
  main --> incense[incense.js]
  main --> smoke[smoke.js]
  main --> ash[ash.js]
  main --> renderer[renderer.js]
  main --> viewport[viewport.js]
  renderer --> Canvas[Canvas 2D]
```

所有 import 都使用带 `.js` 后缀的相对 URL。复制后若修改目录结构，必须同步修改 `main.js` 中的 import 路径。

## 方案 A：独立页面或 iframe

这是风险最低的方式，适合现有项目已有复杂样式、多个框架或严格组件边界的情况。

### 1. 复制完整页面

将本项目的 `index.html`、`styles.css` 和 `src/` 放入宿主项目的静态目录。例如：

```text
public/
  incense/
    index.html
    styles.css
    src/
      ...
```

确认 `index.html` 中的资源路径仍然成立：

```html
<link rel="stylesheet" href="./styles.css">
<script type="module" src="./src/main.js"></script>
```

### 2. 在宿主页面嵌入

```html
<iframe
  src="/incense/index.html"
  title="线香燃烧动画"
  loading="lazy"
  style="width: 100%; height: 720px; border: 0;"
></iframe>
```

宿主布局应给 iframe 明确高度。动画内部会根据 iframe 视口自动适配。

### 3. 优点与限制

优点：

- 不污染宿主 CSS；
- 固定 DOM ID 不会冲突；
- 页面生命周期和事件监听完全隔离；
- SPA 路由卸载 iframe 时，浏览器会自动释放 RAF、Canvas 和监听器。

限制：

- 宿主无法直接操作内部按钮；
- 若需要宿主控制暂停、重置或强度，应增加 `postMessage` 协议，或采用方案 C。

## 方案 B：直接嵌入现有页面

适合传统多页项目，并且该页面只初始化一个线香实例。

### 1. 复制 HTML 结构

将以下结构放入宿主页面。ID 必须保持不变，因为当前 `main.js` 通过这些 ID 查询元素：

```html
<section class="incense-feature" aria-labelledby="incense-title">
  <h2 id="incense-title" class="visually-hidden">一炷静香</h2>

  <section class="canvas-region" aria-label="线香动画场景">
    <canvas
      id="incense-canvas"
      role="img"
      aria-label="香炉中竖立着一根缓慢燃烧、升起烟雾并落下灰烬的线香"
    >
      您的浏览器不支持 Canvas。请升级浏览器后重试。
    </canvas>
  </section>

  <section class="controls" aria-label="燃烧控制">
    <div class="button-group" role="group" aria-label="播放控制">
      <button
        id="toggle-burning"
        type="button"
        aria-label="暂停线香燃烧"
        aria-pressed="false"
      >暂停</button>
      <button
        id="reset-incense"
        type="button"
        aria-label="重新点燃并恢复默认设置"
      >重新点燃</button>
    </div>

    <div class="intensity-control">
      <label for="smoke-intensity">烟雾强度</label>
      <input
        id="smoke-intensity"
        type="range"
        min="0"
        max="100"
        value="50"
        aria-valuetext="50%"
      >
    </div>
  </section>
</section>
```

必需元素：

| ID | 元素类型 | 用途 |
| --- | --- | --- |
| `incense-canvas` | `canvas` | Canvas 2D 渲染目标 |
| `toggle-burning` | `button` | 暂停和继续 |
| `reset-incense` | `button` | 重新点燃并清理旧状态 |
| `smoke-intensity` | `input[type=range]` | 烟雾强度 0–100 |

同一 document 中不能出现第二组相同 ID。当前入口只支持一个实例。

### 2. 隔离并迁移 CSS

不要把当前 `styles.css` 原样引入已有大型页面。以下选择器会影响整个宿主页面：

```css
:root
*
html, body
body
button, input
button
button:focus-visible
input:focus-visible
```

建议执行以下处理：

1. 给组件根元素使用唯一类，例如 `.incense-feature`；
2. 将 `.scene` 改为 `.incense-feature`，或在 HTML 中保留 `.scene` 但为所有组件规则增加 `.incense-feature` 前缀；
3. 不复制 `html`、`body`、`:root` 和通配符规则；
4. 将按钮和输入样式限定在组件根节点内；
5. 由宿主决定组件高度，而不是使用全屏 `100dvh`。

推荐的宿主尺寸边界：

```css
.incense-feature {
  display: grid;
  grid-template-rows: minmax(0, 1fr) auto;
  width: 100%;
  height: min(80dvh, 760px);
  min-height: 420px;
  overflow: hidden;
}

.incense-feature *,
.incense-feature *::before,
.incense-feature *::after {
  box-sizing: border-box;
}

.incense-feature #incense-canvas {
  display: block;
  width: 100%;
  height: 100%;
}
```

然后把原 `styles.css` 中 `.canvas-region`、`.controls`、`.button-group`、`.intensity-control`、按钮、滑块、媒体查询和 `.visually-hidden` 规则复制并加上 `.incense-feature` 前缀。

注意：Canvas 的 CSS 宽高必须由一个具有稳定尺寸的父容器决定。若父容器高度为 `auto` 且没有内容高度，Canvas 可能得到接近 0 的显示高度。

### 3. 加载入口

在 DOM 结构之后加载模块：

```html
<link rel="stylesheet" href="/assets/incense/styles-scoped.css">
<script type="module" src="/assets/incense/src/main.js"></script>
```

`type="module"` 默认延迟到 HTML 解析完成后执行。不要再为同一入口额外添加 `defer`，也不要重复加载 `main.js`。

### 4. 与 Content Security Policy 配合

本项目不使用内联 JavaScript、动态代码执行或远程资源。常见 CSP 可采用：

```http
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'
```

若 CSS 被打包器以内联 style 注入，CSP 规则需按宿主工具链调整。

## 方案 C：集成到 SPA 或组件系统

核心模块可以直接复用，但不要把当前 `main.js` 当作可反复挂载的组件入口。

### 当前入口边界

`main.js` 导入后会立即：

- 使用 `document.querySelector()` 查找固定 ID；
- 创建一个 incense、smoke 和 ash 系统；
- 注册按钮、输入、window resize/orientation 和 document visibility 监听；
- 创建 `ResizeObserver`（若支持）；
- 启动 RAF。

ES Module 在同一页面通常只执行一次，但框架热更新、动态 URL、微前端沙箱或手动重复脚本注入仍可能造成重复监听。当前入口没有公开销毁函数，因此不适合频繁挂载/卸载。

### 推荐封装接口

在 SPA 中，建议先把 `main.js` 的初始化逻辑移动到一个工厂函数：

```js
export function mountIncense(root, options = {}) {
  // 从 root 查询 canvas 和控件，创建系统并注册监听。

  return {
    pause() {},
    resume() {},
    reset() {},
    setSmokeIntensity(value) {},
    destroy() {
      // cancelAnimationFrame
      // cancel resize RAF
      // disconnect ResizeObserver
      // removeEventListener
      // 清理活动粒子引用
    },
  };
}
```

关键要求：

- 所有 DOM 查询都从传入的 `root` 开始，不使用全局固定 ID；
- 每次 mount 创建独立状态；
- destroy 必须取消动画和 resize RAF；
- destroy 必须断开 `ResizeObserver`；
- 事件处理函数必须保存引用，以便移除；
- 页面 Visibility 监听可由共享管理器统一分发，或每个实例独立注册和清理；
- 多实例时，每个 Canvas 使用独立 `SmokeSystem`、`AshSystem` 和 viewport；
- 框架组件卸载钩子必须调用 destroy。

框架生命周期示例：

```js
// 伪代码，适用于 React effect cleanup、Vue onUnmounted 等概念。
const controller = mountIncense(rootElement);

return () => {
  controller.destroy();
};
```

在完成该封装前，SPA 中优先使用 iframe，或者确保线香页面在整个应用生命周期内只挂载一次。

## 配置调整

集中配置位于 `src/config.js`：

- `VIEWPORT_CONFIG`：DPR 上限与最大 deltaTime；
- `CONTROL_CONFIG`：默认烟雾强度；
- `INCENSE_CONFIG`：燃烧速率和火点动态；
- `SCENE_CONFIG`：构图比例与尺寸；
- `SMOKE_CONFIG`：桌面、手机和减少动态的粒子预算；
- `ASH_CONFIG`：灰烬断裂、物理和灰床参数。

集成时优先修改配置，不要在更新循环或 renderer 中散布宿主特定常量。

性能安全线：

- `maxDevicePixelRatio` 建议不超过 2；
- 不要取消 `maxDeltaTime` 限制；
- 不要把粒子数组改成按需无限追加；
- 移动端和 reduced-motion 预算应继续低于桌面预算；
- 主动画只能由一个 RAF 链驱动。

## 打包工具注意事项

### Vite、Webpack、Parcel

可以把 `src/main.js` 作为普通入口导入，但需满足：

- DOM 已存在后再 import；
- CSS 已完成作用域处理；
- 入口只执行一次；
- 打包器保留 Canvas 代码所需的浏览器环境。

动态加载示例：

```js
await import("./incense/src/main.js");
```

只有在目标 DOM 已插入且不会再次卸载时使用该方式。

### Next.js、Nuxt 或 SSR

`main.js` 在模块顶层访问 `document` 和 `window`，不能在服务端执行。必须仅在客户端加载，例如放在客户端生命周期中动态 import。若组件会卸载，仍需先实现方案 C 的 destroy 接口，或使用 iframe。

### TypeScript 项目

JavaScript 模块可以直接被现代 TypeScript 工具链导入。若项目启用了严格的 JavaScript 类型检查，可：

- 对这些文件关闭 `checkJs`；或
- 逐步补充 JSDoc/类型声明；
- 不要在未验证行为前批量改写物理与渲染代码。

## 与宿主应用的常见冲突

### CSS 冲突

症状：宿主按钮、body 滚动、字体或 box-sizing 被改变。

处理：使用作用域 CSS，移除原文件中的全局规则。iframe 不受此问题影响。

### DOM ID 冲突

症状：控制按钮操作错误实例，或初始化时报元素缺失。

处理：页面只保留一组固定 ID；多实例必须先改为 root-scoped 查询。

### 重复初始化

症状：燃烧速度异常、按钮点击切换两次、多个 RAF 或 resize 回调。

处理：确保 `main.js` 只加载一次；SPA 必须使用显式 mount/destroy。

### 容器没有高度

症状：Canvas 空白或只有默认 300×150。

处理：给组件根节点或 Canvas 父容器设置明确的 `height`、`min-height` 或 grid/flex 可分配高度。

### 页面缓存

查询参数不会改变应用功能，只用于区分请求 URL。部署新版本时使用文件内容哈希或构建产物版本号，不要依赖人工查询参数作为长期缓存策略。

## 验收步骤

集成后至少执行以下检查：

1. 打开页面，确认所有模块请求成功且控制台无错误。
2. 确认 Canvas 显示尺寸与 backing store 按 DPR 对应，DPR 上限为 2。
3. 调整宿主容器和窗口尺寸，确认构图更新且燃烧进度不重置。
4. 在手机竖屏和横屏检查无横向溢出，按钮和滑块触控高度至少 44px。
5. 验证暂停、继续、重新点燃和烟雾强度 0/100。
6. 强度设为 0 后，确认旧烟自然消散。
7. 切换页面到后台，确认 RAF 停止；返回后没有时间跳跃。
8. 用户主动暂停后切换后台再返回，确认仍保持暂停。
9. 开启 `prefers-reduced-motion`，确认烟量、摆动和灰烬旋转降低。
10. 重置后确认旧烟、掉落灰烬和灰床累积恢复默认状态。
11. 用键盘操作按钮和滑块，确认焦点可见且 ARIA 状态同步。
12. 长时间运行后确认烟雾池不超过 120，灰烬池不超过 10。
13. 模拟缺少 `ResizeObserver` 和 `matchMedia`，确认应用仍能启动。

## 推荐决策

| 宿主类型 | 推荐方式 |
| --- | --- |
| 静态网站或传统多页应用 | 直接嵌入，先做 CSS 作用域化 |
| 已有复杂设计系统 | iframe，或完成 mount/destroy 封装后嵌入 |
| React/Vue/Angular SPA | 优先 iframe；需要深度交互时实现方案 C |
| CMS 富文本或受限页面 | iframe/static embed |
| 同页多个线香实例 | 必须先实现 root-scoped mount/destroy API |
| SSR 应用 | 客户端动态加载或 iframe，禁止服务端执行 `main.js` |

## 移植检查清单

- [ ] 复制 8 个 JavaScript 模块且相对 import 路径有效。
- [ ] 宿主通过 HTTP(S) 提供 ES Modules。
- [ ] 选择 iframe、单页直接嵌入或 mount/destroy 封装方案。
- [ ] 提供 4 个必需 DOM 元素。
- [ ] Canvas 父容器具有稳定宽高。
- [ ] CSS 已隔离，不覆盖宿主 `html/body/button/input`。
- [ ] `main.js` 不会重复执行。
- [ ] SPA 卸载时能够释放 RAF、Observer 和事件监听。
- [ ] CSP 允许加载本地 module 和 CSS。
- [ ] 完成桌面、手机、后台、减少动态和重置验收。
