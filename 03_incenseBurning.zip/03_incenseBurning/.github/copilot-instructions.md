# Incense Burning Project Instructions

These instructions apply to all code generation and modification in this repository.

## Technology and Portability

- Use native HTML, CSS, JavaScript ES Modules, and Canvas 2D for the initial implementation.
- Keep code framework-independent and portable so modules can be integrated into an existing web project with minimal changes.
- WebGL with custom shaders may be introduced later only when there is a demonstrated visual or performance need. Keep a Canvas 2D fallback and isolate renderer-specific code behind a clear boundary.
- Do not introduce React, Vue, Three.js, or large animation libraries.
- Do not add a build system or runtime dependency unless the task genuinely requires it and the reason is documented.
- Do not use inline JavaScript. Load JavaScript through external ES module files.

## Architecture

- Keep business rules, simulation state updates, and Canvas rendering decoupled.
- Separate responsibilities into focused modules, such as the animation engine, scene state, viewport management, incense model, smoke system, ash system, and renderer.
- Do not place the entire application in one JavaScript file.
- Keep configuration values centralized rather than scattering timing, color, particle, and quality constants throughout the code.
- Read all relevant existing files before modifying code. Preserve completed behavior and unrelated user changes.
- Prefer maintainability, stable frame pacing, and natural visual behavior over unnecessary abstraction or visual complexity.
- Add concise comments only for non-obvious mathematics, numerical integration, noise, or particle behavior.

## Animation and Time

- Drive the main animation loop exclusively with `requestAnimationFrame`.
- Base every animation, simulation, emission rate, and physical update on elapsed time (`deltaTime`), never on frame count.
- Express rates in time-based units such as pixels per second, radians per second, or particles per second.
- Clamp unusually large `deltaTime` values to prevent simulation jumps after stalls.
- Do not use `setInterval` to drive the main animation. Timers may be used only for non-animation work when clearly justified.
- Pause or cancel animation work when the document becomes hidden via the Page Visibility API.
- Reset the frame timestamp when animation resumes so hidden time is not applied as one large update.

## Canvas and Responsive Layout

- Support both desktop and mobile layouts, including portrait and landscape orientations.
- Separate the Canvas CSS display size from its backing-store pixel size.
- Scale the backing store using `window.devicePixelRatio`, with a configurable upper limit to control cost on high-DPI devices.
- Reapply the rendering transform after any Canvas backing-store resize.
- Recalculate Canvas dimensions, scene scale, and composition anchors after `resize` and `orientationchange`.
- Prefer `ResizeObserver` for container-driven sizing and debounce or coalesce repeated resize work.
- Use logical scene coordinates so responsive sizing does not alter simulation behavior.
- Ensure controls and content remain usable with mobile safe areas and do not create horizontal overflow.

## Particles and Physics

- Give every smoke particle an explicit lifecycle: emission, fade-in, rise and expansion, fade-out, expiration, and reuse.
- Use a particle pool, fixed-capacity storage, or strict particle limits for smoke and falling ash. Particle counts must never grow without bounds.
- Limit per-frame particle emission so a slow frame cannot create a large burst of catch-up particles.
- Reuse particle objects and cached drawing resources where practical to reduce garbage collection and rendering overhead.
- Model falling ash with time-based gravity, drag, horizontal air disturbance, angular velocity, and rotation.
- Remove or recycle particles promptly when their lifetime ends or they leave the active scene.
- Keep expensive blur, shadow, gradient, and compositing operations bounded; cache reusable sprites or offscreen rendering assets where appropriate.

## Motion Accessibility

- Support `prefers-reduced-motion: reduce` from the first implementation.
- React to runtime changes of the media query, not only its initial value.
- In reduced-motion mode, lower particle emission and count, reduce smoke sway and ash rotation, and replace rapid ember flicker with slow, subtle variation.
- Preserve the core burning progression and understandable visual state when motion is reduced.

## HTML and Interaction Accessibility

- Use semantic HTML elements appropriate to their purpose.
- Give every button an accessible name through visible text or an appropriate `aria-label`.
- Keep interactive controls in HTML rather than implementing basic form controls inside Canvas.
- Ensure keyboard focus remains visible and controls are operable without a pointer.

## Performance and Validation

- Target smooth 60 fps on capable devices while avoiding excessive CPU and GPU usage.
- Establish separate, bounded quality budgets for desktop, mobile, and reduced-motion modes.
- Avoid per-frame DOM layout reads, unbounded allocations, and rebuilding gradients or buffers unnecessarily.
- After completing each implementation phase, run the narrowest relevant executable check or inspect the result in a browser at desktop and mobile viewport sizes.
- At the end of each phase, report:
  - files modified;
  - validation performed and its result;
  - known limitations or unverified behavior.
- Do not declare a phase complete when its acceptance criteria have not been checked. If a check cannot be run, state why and provide the exact manual verification needed.